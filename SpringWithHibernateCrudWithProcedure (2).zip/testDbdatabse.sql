/*
SQLyog - Free MySQL GUI v5.19
Host - 5.5.28 : Database - testdb
*********************************************************************
Server version : 5.5.28
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `testdb`;

USE `testdb`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `client` */

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `cId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLI_DATEBIRTH` datetime DEFAULT NULL,
  `CLI_LASTNAME` varchar(255) DEFAULT NULL,
  `CLI_NAME` varchar(255) DEFAULT NULL,
  `CLI_REGISTER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `client` */

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `ROLE` varchar(255) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `employee` */

insert into `employee` (`ID`,`NAME`,`ROLE`,`insert_time`) values (1,'Pankaj','CEO','2016-06-08 10:19:20');
insert into `employee` (`ID`,`NAME`,`ROLE`,`insert_time`) values (2,'Pankaj','CEO','2016-06-08 10:24:29');
insert into `employee` (`ID`,`NAME`,`ROLE`,`insert_time`) values (3,'Pankaj','CEO','2016-06-08 12:07:16');
insert into `employee` (`ID`,`NAME`,`ROLE`,`insert_time`) values (4,'Pankaj','CEO','2016-06-08 12:09:05');

/*Table structure for table `employee2` */

DROP TABLE IF EXISTS `employee2`;

CREATE TABLE `employee2` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `insert_time` datetime DEFAULT NULL,
  `NAME` varchar(20) DEFAULT NULL,
  `ROLE` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `employee2` */

insert into `employee2` (`ID`,`insert_time`,`NAME`,`ROLE`) values (1,'2016-06-08 11:52:24','David','Developer');
insert into `employee2` (`ID`,`insert_time`,`NAME`,`ROLE`) values (2,'2016-06-08 11:53:08','Lisa','Manager');
insert into `employee2` (`ID`,`insert_time`,`NAME`,`ROLE`) values (3,'2016-06-08 11:58:59','Lisa','Manager');

/*Table structure for table `employee300` */

DROP TABLE IF EXISTS `employee300`;

CREATE TABLE `employee300` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `dflag` int(11) DEFAULT '0',
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `skill` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `employee300` */

insert into `employee300` (`id`,`address`,`dflag`,`firstname`,`lastname`,`skill`,`gender`) values (1,'gdgdfgdfgfgdfgdfgfdgdfgdfg',0,'ffdgdfgfdgfdg','gffdgdgdgfdfgdf',NULL,NULL);
insert into `employee300` (`id`,`address`,`dflag`,`firstname`,`lastname`,`skill`,`gender`) values (2,'ghghghgfhgf',0,'gfhfgh','gfhgfhfwerfwwff','javaphp.net',NULL);
insert into `employee300` (`id`,`address`,`dflag`,`firstname`,`lastname`,`skill`,`gender`) values (3,'ghghghgfhgfbnvbnbvnbvnbvnbvnbvnbvnbvnbnbvnbnbvnbvn',0,'gfhfghbnnnbbvnvnbnbvnvbnbvn','gfhgfhfwerfwwffbnnbvbvvbnvbn','.net',NULL);
insert into `employee300` (`id`,`address`,`dflag`,`firstname`,`lastname`,`skill`,`gender`) values (4,'ghgfhdfhgfhgfgf',0,'ponik','cvvbvcbc','php',NULL);
insert into `employee300` (`id`,`address`,`dflag`,`firstname`,`lastname`,`skill`,`gender`) values (5,'dfgdfg',0,'dfggdg','dfgdfgdfg','java',NULL);

/*Table structure for table `employee400` */

DROP TABLE IF EXISTS `employee400`;

CREATE TABLE `employee400` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `dflag` enum('1','0') DEFAULT '1',
  `skill` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `employee400` */

insert into `employee400` (`id`,`address`,`firstname`,`lastname`,`dflag`,`skill`) values (1,'7-A vaishavanar sco. malapur road modasa pin code 383315cvbcvb','pratikcvbcvb','joshicvcv','1','red,blue,green');
insert into `employee400` (`id`,`address`,`firstname`,`lastname`,`dflag`,`skill`) values (2,'7-A vaishavanar sco. malapur road modasa pin code 383315cvbcvb','pratikcvbcvb','joshicvcv','1','red,blue');
insert into `employee400` (`id`,`address`,`firstname`,`lastname`,`dflag`,`skill`) values (3,'fdfgdfgdfgdfg','gdfgfdgds','fgfghgfghh','1','red');
insert into `employee400` (`id`,`address`,`firstname`,`lastname`,`dflag`,`skill`) values (4,'gffghgfhghghghgf','ghjkhjkhjkhj','jhhjkhjkh','1','red,blue,green');

/*Table structure for table `employeep` */

DROP TABLE IF EXISTS `employeep`;

CREATE TABLE `employeep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `dflag` int(11) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

/*Data for the table `employeep` */

insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (1,'fdgdfgdfgsdfsdfsdf',1,'fgdfgdfgsdfsdffdsdf','male','fgdfgddsfsdf');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (2,'fdgdfgdfg',0,'fggfdfgdfg','dfgdfg','gdfgdfg');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (4,'gfddgdfgdfg',0,'pratikj','male','joshi');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (5,'gfddgdfgdfg',1,'pratik','male','joshi');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (6,'gfddgdfgdfg',1,'pratik','male','joshi');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (7,'gfddgdfgdfgffg',1,'pratikj','mail','joshij');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (8,'gfddgdfgdfg',1,'pratik','male','joshi');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (9,'ffdfgdfgdfg',1,'pratik','male','joshi');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (11,'fgdfgdfg',1,'fgfdf','mail','dffgfdg');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (12,'fgdfgdfg',1,'fgfdf','fgdfgdfg','dffgfdg');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (13,'fgdfgdfg',1,'fgfdftrtyert','fgdfgdfg','dffgfdg');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (14,'fgdfgdfg',0,'fdgdfgdf','fgfgdfg','fdgdfg');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (15,'FDGDFGDFGD',0,'TDFGHDFG','GFGDFGDFG','FGDFGDF');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (16,'FDGDFGDFGD',1,'TDFGHDFG','GFGDFGDFG','FGDFGDF');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (17,'FDGDFGDFGD',1,'TDFGHDFG','GFGDFGDFG','FGDFGDF');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (18,'FDGDFGDFGD',0,'TDFGHDFG','GFGDFGDFG','FGDFGDF');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (19,'GDFGDFGDFG',1,'PRATIK','MALE','JOSHI');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (20,'dfgfgdfgdfg',1,'maulik','male','patel');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (21,'sdfsdfsdfsd',1,'fdfdfg','male','varma');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (22,'ggfgdffg',0,'pratik','male','jani');
insert into `employeep` (`id`,`address`,`dflag`,`firstname`,`gender`,`lastname`) values (23,'hfghgfhfggf',0,'gffggfhgf','male','ghfghfghgfhgfh');

/*Table structure for table `person` */

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `person` */

/* Procedure structure for procedure `getAllEmprecord` */

drop procedure if exists `getAllEmprecord`;

DELIMITER $$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllEmprecord`(
)
BEGIN
select * from employeep where dflag = 1;
END$$

DELIMITER ;

/* Procedure structure for procedure `getAllrecord` */

drop procedure if exists `getAllrecord`;

DELIMITER $$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllrecord`(
)
BEGIN
select * from employeep;
END$$

DELIMITER ;

/* Procedure structure for procedure `getrecord` */

drop procedure if exists `getrecord`;

DELIMITER $$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getrecord`(
IN int_id Integer)
BEGIN
select * from employeep where ID =int_id;
END$$

DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
