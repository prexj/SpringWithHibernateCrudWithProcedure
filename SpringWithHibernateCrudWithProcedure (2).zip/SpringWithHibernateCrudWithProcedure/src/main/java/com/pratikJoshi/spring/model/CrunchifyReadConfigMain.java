package com.pratikJoshi.spring.model;

import java.io.IOException;

public class CrunchifyReadConfigMain {
	
	public static void main(String[] args) throws IOException {
		CrunchifyGetPropertyValues properties = new CrunchifyGetPropertyValues();
		properties.getPropValues();
	}
}
